/**
 * List of available tools for the chat interface
 * This is the source of truth for all tool references
 */
export const AVAILABLE_TOOLS = ["@vault", "@websearch", "@composer", "@memory"];
