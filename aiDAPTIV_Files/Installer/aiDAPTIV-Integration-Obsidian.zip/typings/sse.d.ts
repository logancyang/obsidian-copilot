declare module "sse";
